local mod = get_mod("Mourningstar_dialogue_improved")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "general_settings",
				type = "group",
				tab = mod:localize("General"),
				sub_widgets = {
					{
						setting_id = "mod_name_pizazz_toggle",
						type = "checkbox",
						default_value = true,
						tooltip = "mod_name_pizazz_tooltip",
					},
					{
						setting_id = "show_custom_radio_subtitles",
						type = "checkbox",
						default_value = true,
						tooltip = "show_custom_radio_subtitles_tooltip",
					},
				},
			},
			{
				setting_id = "mourningstar_settings",
				type = "group",
				tab = mod:localize("Mourningstar"),
				sub_widgets = {
					{

						setting_id = "disable_mourningstar_chatter",
						type = "checkbox",
						default_value = false,
						tooltip = "disable_mourningstar_chatter_tooltip",
					},
					{

						setting_id = "disable_mission_update_chatter",
						type = "checkbox",
						default_value = false,
						tooltip = "disable_mission_update_chatter_tooltip",
					},
					{

						setting_id = "disable_vocator_updates",
						type = "checkbox",
						default_value = false,
						tooltip = "disable_vocator_updates_tooltip",
					},
				},
			},
			{
				setting_id = "inmission_settings",
				type = "group",
				tab = mod:localize("inmission"),
				sub_widgets = {
					{

						setting_id = "disable_radio_chatter",
						type = "checkbox",
						default_value = false,
						tooltip = "disable_radio_chatter_tooltip",
					},
					{

						setting_id = "disable_all_chatter",
						type = "checkbox",
						default_value = false,
						tooltip = "disable_all_chatter_tooltip",
					},

					--[[
					{
						setting_id = "mourningstar_chatter_spacing",
						type = "numeric",
						default_value = 10,
						range = { 1, 60 },
						decimals_number = 2,
						tooltip = "mourningstar_chatter_spacing_tooltip",
					},]]
				},
			},
		},
	},
}
